import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_naver_map/flutter_naver_map.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'gps_service.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final String directionsUrl = 'http://59.26.209.104:8081/test/directions';
  final String waypointsUrl = 'http://59.26.209.104:8081/test/route';
  late NaverMapController _mapController;
  List<NLatLng> _pathCoordinates = [];
  List<NMarker> _markers = [];
  bool _isMapReady = false;
  bool _isLoading = false;
  
  // GPS 서비스
  late GpsService _gpsService;
  
  // 상태 변수 
  bool _isMoving = false;
  NLatLng? _currentPosition;
  
  @override
  void initState() {
    super.initState();
    
    // GPS 서비스 초기화
    _gpsService = GpsService(
      onPositionChanged: (position) {
        setState(() {
          _currentPosition = position;
        });
      },
      onMarkerUpdated: () {
        // 마커가 업데이트되었을 때 필요한 UI 업데이트
        setState(() {});
      },
      onMovingStatusChanged: (isMoving) {
        setState(() {
          _isMoving = isMoving;
        });
      },
    );
    
    // 위치 권한 요청
    _gpsService.requestLocationPermission();
  }
  
  @override
  void dispose() {
    _gpsService.dispose();
    super.dispose();
  }
  
  /// 📌 경로 및 경유지 데이터 가져오기
  Future<void> _fetchRouteAndWaypoints() async {
    if (!_isMapReady) return;
    
    try {
      await _fetchRoute();
      await _fetchWaypoints();
    } catch (e) {
      print('경로 및 경유지 가져오기 중 오류: $e');
    }
  }

  /// 📌 경유지 가져오기 (`/test/route`)
  Future<void> _fetchWaypoints() async {
    if (!_isMapReady) return;
    
    try {
      final response = await http.get(Uri.parse(waypointsUrl));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        final List<dynamic> waypointsRaw = data['orderedCoordinates'];
        final List<List<double>> waypoints = waypointsRaw.map((coord) => List<double>.from(coord)).toList();

        // 기존 마커 제거
        for (var marker in _markers) {
          if (_isMapReady) {
            _mapController.deleteOverlay(marker.info);
          }
        }

        List<NMarker> markers = [];
        for (int i = 0; i < waypoints.length; i++) {
          final lat = waypoints[i][0];
          final lng = waypoints[i][1];
          markers.add(
            NMarker(
              id: 'waypoint_marker_$i',
              position: NLatLng(lat, lng),
              caption: NOverlayCaption(
                text: '${i + 1}',
              ),
            ),
          );
        }

        setState(() {
          _markers = markers;
          _drawMarkers();
        });
      } else {
        print('경유지 데이터를 가져오지 못했습니다. 상태 코드: ${response.statusCode}');
      }
    } catch (e) {
      print('경유지 데이터 요청 중 오류 발생: $e');
    }
  }
  
  Future<void> _fetchRoute() async {
    if (!_isMapReady) return;
    
    setState(() => _isLoading = true);
    try {
      final response = await http.get(Uri.parse(directionsUrl));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final path = (data['route']['path'] as List).map((coords) {
          return NLatLng((coords[0] as num?)?.toDouble() ?? 0.0, (coords[1] as num?)?.toDouble() ?? 0.0);
        }).toList();
        
        final List<NMarker> guideMarkers = [];
        if (data['route']['guide'] != null) {
          final guides = data['route']['guide'] as List;
          for (int i = 0; i < guides.length; i++) {
            final point = guides[i];
            guideMarkers.add(
              NMarker(
                id: 'guide_marker_$i',
                position: NLatLng(
                  (point['lat'] as num?)?.toDouble() ?? 0.0,
                  (point['lng'] as num?)?.toDouble() ?? 0.0
                ),
              ),
            );
          }
        }
        
        setState(() {
          // 기존 경로 삭제
          _mapController.clearOverlays(type: NOverlayType.pathOverlay);
          
          _pathCoordinates = path;
          _drawPath();
          
          if (_pathCoordinates.isNotEmpty) {
            // 1단계: 전체 경로를 볼 수 있게 카메라 조정
            // 경로의 시작점과 끝점으로 경계 생성
            NLatLng firstCoord = _pathCoordinates.first;
            NLatLng lastCoord = _pathCoordinates.last;
            
            // 모든 좌표를 순회하며 최대/최소 좌표 찾기
            double minLat = firstCoord.latitude;
            double maxLat = firstCoord.latitude;
            double minLng = firstCoord.longitude;
            double maxLng = firstCoord.longitude;
            
            for (NLatLng coord in _pathCoordinates) {
              minLat = min(minLat, coord.latitude);
              maxLat = max(maxLat, coord.latitude);
              minLng = min(minLng, coord.longitude);
              maxLng = max(maxLng, coord.longitude);
            }
            
            // 경계 생성
            NLatLngBounds bounds = NLatLngBounds(
              southWest: NLatLng(minLat, minLng),
              northEast: NLatLng(maxLat, maxLng),
            );
            
            // 카메라 업데이트 - 전체 경로 표시
            _mapController.updateCamera(
              NCameraUpdate.fitBounds(
                bounds,
                padding: EdgeInsets.all(50),
              ),
            );
            
            // 2단계: 잠시 후 출발 지점으로 줌인 (딜레이 추가)
            Future.delayed(Duration(milliseconds: 1500), () {
              if (!mounted) return;
              
              // 출발 지점(첫 번째 좌표)으로 이동하고 확대
              _mapController.updateCamera(
                NCameraUpdate.scrollAndZoomTo(
                  target: _pathCoordinates.first,
                  zoom: 17.0, // 확대 레벨
                ),
              );
            });
          }
        });
      } else {
        print('경로 데이터를 가져오지 못했습니다. 상태 코드: ${response.statusCode}');
      }
    } catch (e) {
      print('경로 데이터 요청 중 오류 발생: $e');
    }
    setState(() => _isLoading = false);
  }
  
  void _drawPath() {
    if (!_isMapReady || _pathCoordinates.isEmpty) return;
    
    try {
      final pathOverlay = NPathOverlay(
        id: 'path_overlay',
        coords: _pathCoordinates,
        color: Colors.blue,
        width: 5,
      );
      _mapController.addOverlay(pathOverlay);
    } catch (e) {
      print('경로 그리기 중 오류 발생: $e');
    }
  }

  void _drawMarkers() {
    if (!_isMapReady) return;
    
    try {
      for (final marker in _markers) {
        _mapController.addOverlay(marker);
      }
    } catch (e) {
      print('마커 그리기 중 오류 발생: $e');
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('경로 안내'),
      ),
      body: Stack(
        children: [
          NaverMap(
            options: const NaverMapViewOptions(
              locationButtonEnable: false,
              indoorEnable: false,
              nightModeEnable: false,
              liteModeEnable: false,
              buildingHeight: 1.0,
              logoMargin: EdgeInsets.only(bottom: 20, right: 20),
            ),  
            onMapReady: (controller) {
              setState(() {
                _mapController = controller;
                _isMapReady = true;
                
                // GPS 서비스에 컨트롤러 전달
                _gpsService.initialize(controller);
              });
            },
            onMapTapped: (point, latLng) {
              _gpsService.onMapTapped(latLng);
            },
          ),
          if (_isLoading) Center(child: CircularProgressIndicator()),
          
          // 줌 버튼
          Positioned(
            bottom: 80,
            right: 20,
            child: Column(
              children: [
                FloatingActionButton(
                  onPressed: () {
                    if (_isMapReady) {
                      _mapController.updateCamera(NCameraUpdate.zoomIn());
                    }
                  },
                  child: Icon(Icons.add),
                  mini: true,
                ),
                SizedBox(height: 10),
                FloatingActionButton(
                  onPressed: () {
                    if (_isMapReady) {
                      _mapController.updateCamera(NCameraUpdate.zoomOut());
                    }
                  },
                  child: Icon(Icons.remove),
                  mini: true,
                ),
              ],
            ),
          ),
          
          // 경로 요청 버튼
          Positioned(
            bottom: 140,
            left: 20,
            child: FloatingActionButton(
              onPressed: _fetchRouteAndWaypoints, 
              child: Icon(Icons.directions),
            ),
          ),
          
          // GPS 이동 모드 버튼 (아이콘만 표시하도록 수정)
          Positioned(
            bottom: 70,
            left: 20,
            child: FloatingActionButton(
              onPressed: () {
                _gpsService.toggleGpsMoveMode();
                setState(() {}); // UI 업데이트
              },
              backgroundColor: _gpsService.isGpsMoveEnabled ? Colors.green : Colors.blue,
              child: Icon(_gpsService.isGpsMoveEnabled ? Icons.gps_fixed : Icons.gps_not_fixed),
            ),
          ),
          
          // 현재 이동 상태 및 위치 정보 표시
          Positioned(
            top: 20,
            left: 0,
            right: 0,
            child: Center(
              child: Column(
                children: [
                  if (_isMoving)
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '목적지로 이동 중...',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  if (_currentPosition != null && _gpsService.isGpsMoveEnabled)
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '현재 위치: ${_currentPosition!.latitude.toStringAsFixed(6)}, ${_currentPosition!.longitude.toStringAsFixed(6)}',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}